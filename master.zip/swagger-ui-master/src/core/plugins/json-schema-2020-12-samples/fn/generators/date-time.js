/**
 * @prettier
 */
const dateTimeGenerator = () => new Date().toISOString()

export default dateTimeGenerator
