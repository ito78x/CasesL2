/**
 * @prettier
 */
const int32Generator = () => (2 ** 30) >>> 0

export default int32Generator
